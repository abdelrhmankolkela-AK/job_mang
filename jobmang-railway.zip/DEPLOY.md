# نشر Nexthire على الإنترنت (رابط دائم)

## رابط مؤقت للتجربة من الموبايل (الكمبيوتر شغال)

إذا شغّلت `npm start` والنفق (tunnel) شغال، افتح الرابط الذي يظهر في الطرفية.

عند أول زيارة من loca.lt قد يطلب **Tunnel Password** — أدخل **IP جهازك العام** (يظهر في صفحة التحذير أو من https://api.ipify.org).

---

## رابط دائم مجاني على Render (موصى به)

1. أنشئ حساباً على [render.com](https://render.com) (مجاني).
2. ارفع المشروع على GitHub:
   - أنشئ repo جديداً على github.com
   - ارفع ملفات المشروع (أو `git push` من جهازك)
3. في Render: **New +** → **Blueprint** → اربط الـ repo
4. Render يقرأ `render.yaml` تلقائياً وينشر المشروع
5. بعد 3–5 دقائق ستحصل على رابط مثل: `https://nexthire-xxxx.onrender.com`

### حساب المدير بعد النشر

- `/admin/login`
- `admin@nexthire.com` / `Admin123!`
- غيّر `ADMIN_EMAIL` و `ADMIN_PASSWORD` في Environment Variables على Render
