document.addEventListener("DOMContentLoaded", async () => {
  const container = document.getElementById("featuredJobsContainer");
  if (!container) return;

  try {
    const jobs = await getJobs();
    const featured = jobs.slice(0, 3);

    if (featured.length === 0) {
      container.innerHTML = "<p class='col-span-full text-center text-gray-500 py-8'>لا توجد وظائف حالياً</p>";
      return;
    }

    container.innerHTML = featured.map(job => `
      <div class="bg-white p-5 rounded-xl shadow card-hover transition-custom">
        <h3 class="text-xl font-bold text-blue-800">${escapeHtml(job.title)}</h3>
        <p class="text-gray-600 mt-2">
          <i class="fas fa-building ml-1"></i> ${escapeHtml(job.company_name || 'شركة')}
          <span class="mx-1">|</span>
          <i class="fas fa-map-marker-alt ml-1"></i> ${escapeHtml(job.location || 'غير محدد')}
        </p>
        <p class="text-gray-500 mt-1 text-sm">${escapeHtml((job.description || '').substring(0, 80))}...</p>
        <div class="mt-4 flex justify-between items-center flex-wrap gap-2">
          <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded text-sm">${escapeHtml(job.industry || 'عام')}</span>
          <a href="jobs.html" class="text-blue-600 hover:underline">تفاصيل <i class="fas fa-arrow-left mr-1"></i></a>
        </div>
      </div>
    `).join("");
  } catch (error) {
    console.error(error);
    container.innerHTML = "<p class='col-span-full text-center text-red-500 py-8'>تعذر تحميل الوظائف. تأكد من تشغيل الخادم.</p>";
  }
});

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/[&<>]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m]));
}
