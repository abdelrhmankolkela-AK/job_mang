# رفع المشروع على GitHub + GitHub Pages

## الخطوة 1 — تسجيل الدخول لـ GitHub (مرة واحدة)

افتح PowerShell في مجلد المشروع ونفّذ:

```bash
gh auth login
```

اختر: GitHub.com → HTTPS → Login with browser

## الخطوة 2 — رفع المشروع وإنشاء الريبو

```bash
cd "e:\user\Downloads\jobmang-main (1)\jobmang-main"
git branch -M main
git commit -m "Nexthire: job portal with admin dashboard and GitHub Pages"
gh repo create nexthire --public --source=. --remote=origin --push
```

> إذا الاسم `nexthire` مستخدم، غيّره: `gh repo create nexthire-app --public ...`

## الخطوة 3 — تفعيل GitHub Pages

1. افتح الريبو على GitHub
2. **Settings** → **Pages**
3. تحت **Build and deployment** → Source: **GitHub Actions**
4. بعد دقيقتين من أول push، الرابط يكون:

**https://اسم-المستخدم.github.io/nexthire/**

(استبدل `اسم-المستخدم` واسم الريبو)

## حسابات التجربة على Pages

| الدور | البريد | كلمة المرور |
|--------|--------|-------------|
| باحث | user@test.com | 123456 |
| شركة | company@test.com | 123456 |
| مدير | admin@nexthire.com | Admin123! |

> على GitHub Pages البيانات تُحفظ في متصفحك (وضع تجريبي). للنسخة الكاملة مع قاعدة بيانات استخدم Render — انظر `DEPLOY.md`.
