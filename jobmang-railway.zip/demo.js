// بيانات تجريبية لـ GitHub Pages (بدون خادم Node)
function seedDemoData() {
  if (localStorage.getItem('nexthire_demo_seeded')) return;

  const companyCode = 'demo-company-1';
  const seekerCode = 'demo-seeker-1';
  const job1 = 'demo-job-1';
  const job2 = 'demo-job-2';

  const users = [
    { code: companyCode, name: 'شركة تقنية', email: 'company@test.com', password: '123456', type: 'company', created_at: new Date().toISOString() },
    { code: seekerCode, name: 'أحمد محمد', email: 'user@test.com', password: '123456', type: 'job_seeker', created_at: new Date().toISOString() }
  ];

  const jobs = [
    { code: job1, company_code: companyCode, title: 'مطور Frontend', description: 'React و JavaScript', industry: 'تقنية', location: 'القاهرة', created_at: new Date().toISOString(), company_name: 'شركة تقنية' },
    { code: job2, company_code: companyCode, title: 'مسوق رقمي', description: 'إدارة حملات التواصل', industry: 'تسويق', location: 'دبي', created_at: new Date().toISOString(), company_name: 'شركة تقنية' }
  ];

  const applications = [
    { code: 'demo-app-1', user_code: seekerCode, job_code: job1, status: 'pending', applied_at: new Date().toISOString(), job_title: 'مطور Frontend', company_name: 'شركة تقنية' }
  ];

  const companies = {};
  companies[companyCode] = {
    user_code: companyCode,
    company_name: 'شركة تقنية',
    industry: 'تقنية المعلومات',
    location: 'القاهرة',
    description: 'شركة رائدة',
    contact_email: 'company@test.com',
    phone: '',
    website: ''
  };

  const skills = {
    [seekerCode]: [{ code: 's1', name: 'JavaScript' }, { code: 's2', name: 'React' }]
  };

  localStorage.setItem('jobportal_users', JSON.stringify(users));
  localStorage.setItem('jobportal_jobs', JSON.stringify(jobs));
  localStorage.setItem('jobportal_applications', JSON.stringify(applications));
  localStorage.setItem('jobportal_companies', JSON.stringify(companies));
  localStorage.setItem('jobportal_skills', JSON.stringify(skills));
  localStorage.setItem('nexthire_demo_seeded', '1');
}

if (window.NEXTHIRE_CONFIG?.isDemoMode) {
  seedDemoData();
}
