// utils.js - API أو وضع تجريبي على GitHub Pages

function isDemoMode() {
  return !!(window.NEXTHIRE_CONFIG && window.NEXTHIRE_CONFIG.isDemoMode);
}

const API_BASE = (() => {
  if (window.NEXTHIRE_CONFIG) return window.NEXTHIRE_CONFIG.apiBase || window.location.origin;
  if (window.location.protocol === 'file:') return 'http://localhost:3000';
  return window.location.origin;
})();

let currentUser = null;

const STORAGE_USERS = 'jobportal_users';
const STORAGE_JOBS = 'jobportal_jobs';
const STORAGE_APPLICATIONS = 'jobportal_applications';
const STORAGE_COMPANIES = 'jobportal_companies';
const STORAGE_SKILLS = 'jobportal_skills';

function getUsersLocal() {
  return JSON.parse(localStorage.getItem(STORAGE_USERS) || '[]');
}
function saveUsers(users) { localStorage.setItem(STORAGE_USERS, JSON.stringify(users)); }
function getJobsLocal() {
  return JSON.parse(localStorage.getItem(STORAGE_JOBS) || '[]');
}
function saveJobs(jobs) { localStorage.setItem(STORAGE_JOBS, JSON.stringify(jobs)); }
function getApplications() {
  return JSON.parse(localStorage.getItem(STORAGE_APPLICATIONS) || '[]');
}
function saveApplications(apps) { localStorage.setItem(STORAGE_APPLICATIONS, JSON.stringify(apps)); }
function getCompaniesData() {
  return JSON.parse(localStorage.getItem(STORAGE_COMPANIES) || '{}');
}
function saveCompaniesData(data) { localStorage.setItem(STORAGE_COMPANIES, JSON.stringify(data)); }
function getSkillsMap() {
  return JSON.parse(localStorage.getItem(STORAGE_SKILLS) || '{}');
}
function saveSkillsMap(map) { localStorage.setItem(STORAGE_SKILLS, JSON.stringify(map)); }

function getCurrentUser() {
  if (currentUser) return currentUser;
  const stored = sessionStorage.getItem('currentUser');
  if (stored) currentUser = JSON.parse(stored);
  return currentUser;
}
function setCurrentUser(user) {
  currentUser = user;
  sessionStorage.setItem('currentUser', JSON.stringify(user));
}
function logout() {
  currentUser = null;
  sessionStorage.removeItem('currentUser');
  window.location.href = 'index.html';
}

function uid() {
  return 'id-' + Math.random().toString(36).slice(2, 11);
}

async function apiCall(endpoint, options = {}) {
  const url = `${API_BASE}/api${endpoint}`;
  const response = await fetch(url, {
    method: options.method || 'GET',
    headers: { 'Content-Type': 'application/json' },
    body: options.body || null
  });
  const contentType = response.headers.get('content-type');
  if (!contentType || !contentType.includes('application/json')) {
    throw new Error('الخادم لم يرد باستجابة صحيحة');
  }
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'حدث خطأ في الطلب');
  return data;
}

async function registerUser(userData) {
  if (isDemoMode()) {
    const users = getUsersLocal();
    if (users.some(u => u.email === userData.email)) throw new Error('البريد الإلكتروني موجود مسبقاً');
    const code = uid();
    users.push({ code, name: userData.name, email: userData.email, password: userData.password, type: userData.type, created_at: new Date().toISOString() });
    saveUsers(users);
    if (userData.type === 'company') {
      const companies = getCompaniesData();
      companies[code] = { user_code: code, company_name: userData.company_name || userData.name, industry: '', location: '', description: '', contact_email: userData.contact_email || userData.email, phone: '', website: '' };
      saveCompaniesData(companies);
    }
    return { success: true };
  }
  return apiCall('/register', { method: 'POST', body: JSON.stringify(userData) });
}

async function loginUser(email, password) {
  if (isDemoMode()) {
    const user = getUsersLocal().find(u => u.email === email && u.password === password);
    if (!user) return false;
    const { password: _, ...safe } = user;
    setCurrentUser(safe);
    return true;
  }
  const data = await apiCall('/login', { method: 'POST', body: JSON.stringify({ email, password }) });
  if (data.success && data.user) { setCurrentUser(data.user); return true; }
  return false;
}

async function getUsers() {
  if (isDemoMode()) return getUsersLocal().map(({ password, ...u }) => u);
  try { return await apiCall('/users'); } catch { return getUsersLocal(); }
}

async function getJobs() {
  if (isDemoMode()) return getJobsLocal();
  try { return await apiCall('/jobs'); } catch { return getJobsLocal(); }
}

async function createJob(jobData) {
  if (isDemoMode()) {
    const jobs = getJobsLocal();
    const users = getUsersLocal();
    const company = users.find(u => u.code === jobData.company_code);
    const code = uid();
    jobs.unshift({ code, ...jobData, created_at: new Date().toISOString(), company_name: company?.name || 'شركة' });
    saveJobs(jobs);
    return { success: true, job_code: code };
  }
  return apiCall('/jobs', { method: 'POST', body: JSON.stringify(jobData) });
}

async function deleteJob(jobCode) {
  if (isDemoMode()) {
    saveJobs(getJobsLocal().filter(j => j.code !== jobCode));
    saveApplications(getApplications().filter(a => a.job_code !== jobCode));
    return { success: true };
  }
  return apiCall(`/jobs/${jobCode}`, { method: 'DELETE' });
}

async function applyToJob(userCode, jobCode) {
  if (isDemoMode()) {
    const apps = getApplications();
    if (apps.some(a => a.user_code === userCode && a.job_code === jobCode)) throw new Error('سبق لك التقديم على هذه الوظيفة');
    const job = getJobsLocal().find(j => j.code === jobCode);
    const user = getUsersLocal().find(u => u.code === userCode);
    apps.unshift({
      code: uid(), user_code: userCode, job_code: jobCode, status: 'pending', applied_at: new Date().toISOString(),
      job_title: job?.title, company_name: job?.company_name, user_name: user?.name, user_email: user?.email
    });
    saveApplications(apps);
    return { success: true };
  }
  return apiCall('/applications', { method: 'POST', body: JSON.stringify({ user_code: userCode, job_code: jobCode }) });
}

async function getCompanyApplications(companyCode) {
  if (isDemoMode()) {
    const jobIds = getJobsLocal().filter(j => j.company_code === companyCode).map(j => j.code);
    return getApplications().filter(a => jobIds.includes(a.job_code)).map(a => {
      const user = getUsersLocal().find(u => u.code === a.user_code);
      const job = getJobsLocal().find(j => j.code === a.job_code);
      return { ...a, user_name: user?.name, user_email: user?.email, job_title: job?.title };
    });
  }
  return apiCall(`/company-applications/${companyCode}`);
}

async function updateApplicationStatus(appCode, status) {
  if (isDemoMode()) {
    const apps = getApplications().map(a => a.code === appCode ? { ...a, status } : a);
    saveApplications(apps);
    return { success: true };
  }
  return apiCall(`/applications/${appCode}`, { method: 'PUT', body: JSON.stringify({ status }) });
}

async function getCompanyProfile(userCode) {
  if (isDemoMode()) return getCompaniesData()[userCode] || {};
  return apiCall(`/company-profile/${userCode}`);
}

async function updateCompanyProfile(userCode, profileData) {
  if (isDemoMode()) {
    const companies = getCompaniesData();
    companies[userCode] = { ...companies[userCode], user_code: userCode, ...profileData };
    saveCompaniesData(companies);
    return { success: true };
  }
  return apiCall(`/company-profile/${userCode}`, { method: 'PUT', body: JSON.stringify(profileData) });
}

async function getCompanyJobs(companyCode) {
  if (isDemoMode()) return getJobsLocal().filter(j => j.company_code === companyCode);
  return apiCall(`/company-jobs/${companyCode}`);
}

async function getUserSkills(userCode) {
  if (isDemoMode()) return getSkillsMap()[userCode] || [];
  return apiCall(`/user-skills/${userCode}`);
}

async function updateUserSkills(userCode, skills) {
  if (isDemoMode()) {
    const map = getSkillsMap();
    map[userCode] = skills.filter(Boolean).map(name => ({ code: uid(), name: name.trim() }));
    saveSkillsMap(map);
    return { success: true, skills: map[userCode] };
  }
  return apiCall(`/user-skills/${userCode}`, { method: 'PUT', body: JSON.stringify({ skills }) });
}

async function getUserApplications(userCode) {
  if (isDemoMode()) {
    return getApplications().filter(a => a.user_code === userCode);
  }
  return apiCall(`/user-applications/${userCode}`);
}

async function updateUserProfile(userCode, profileData) {
  if (isDemoMode()) {
    const users = getUsersLocal();
    const i = users.findIndex(u => u.code === userCode);
    if (i >= 0 && profileData.name) users[i].name = profileData.name;
    saveUsers(users);
    const u = users[i];
    const { password, ...safe } = u;
    return { success: true, user: safe };
  }
  return apiCall(`/users/${userCode}`, { method: 'PUT', body: JSON.stringify(profileData) });
}

window.getUsersLocal = getUsersLocal;
window.saveUsers = saveUsers;
window.getJobsLocal = getJobsLocal;
window.saveJobs = saveJobs;
window.getApplications = getApplications;
window.saveApplications = saveApplications;
window.getCompaniesData = getCompaniesData;
window.saveCompaniesData = saveCompaniesData;
window.getCurrentUser = getCurrentUser;
window.setCurrentUser = setCurrentUser;
window.logout = logout;
window.registerUser = registerUser;
window.loginUser = loginUser;
window.getUsers = getUsers;
window.getJobs = getJobs;
window.createJob = createJob;
window.deleteJob = deleteJob;
window.applyToJob = applyToJob;
window.getCompanyApplications = getCompanyApplications;
window.updateApplicationStatus = updateApplicationStatus;
window.getCompanyProfile = getCompanyProfile;
window.updateCompanyProfile = updateCompanyProfile;
window.getCompanyJobs = getCompanyJobs;
window.getUserSkills = getUserSkills;
window.updateUserSkills = updateUserSkills;
window.getUserApplications = getUserApplications;
window.updateUserProfile = updateUserProfile;
window.isDemoMode = isDemoMode;

console.log('✅ utils.js', isDemoMode() ? '(وضع GitHub Pages التجريبي)' : API_BASE);
