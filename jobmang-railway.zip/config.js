// إعدادات الموقع حسب بيئة الاستضافة
(function () {
  const host = window.location.hostname;
  const isGitHubPages = host.endsWith('github.io');
  const isLocalFile = window.location.protocol === 'file:';

  window.NEXTHIRE_CONFIG = {
    isGitHubPages,
    isDemoMode: isGitHubPages,
    // غيّر هذا بعد نشر الـ API على Render (اختياري للنسخة الكاملة)
    apiBase: isLocalFile
      ? 'http://localhost:3000'
      : (isGitHubPages ? '' : window.location.origin),
    siteBase: isGitHubPages
      ? '/' + (window.location.pathname.split('/').filter(Boolean)[0] || '') + '/'
      : '/'
  };
  if (window.NEXTHIRE_CONFIG.siteBase !== '/' && !window.NEXTHIRE_CONFIG.siteBase.endsWith('/')) {
    window.NEXTHIRE_CONFIG.siteBase += '/';
  }
})();
