# Nexthire - منصة التوظيف

منصة ويب عربية لربط الباحثين عن عمل بالشركات، مع لوحة تحكم للشركات والباحثين ولوحة إدارة للمشرف.

## التشغيل السريع

```bash
npm install
npm start
```

افتح المتصفح على: **http://localhost:3000**

> يجب تشغيل المشروع عبر الخادم (`npm start`) وليس بفتح ملفات HTML مباشرة.

## حسابات تجريبية

| الدور | البريد | كلمة المرور |
|--------|--------|-------------|
| شركة | company@test.com | 123456 |
| باحث عن عمل | user@test.com | 123456 |
| مدير النظام | admin@nexthire.com | Admin123! |

- لوحة الشركة: http://localhost:3000/company-dashboard.html
- لوحة الباحث: http://localhost:3000/user-dashboard.html
- لوحة المدير: http://localhost:3000/admin/login

## متغيرات البيئة (اختياري)

| المتغير | الوصف | الافتراضي |
|---------|--------|-----------|
| `PORT` | منفذ الخادم | 3000 |
| `DATABASE_PATH` | مسار SQLite | ./database.db |
| `ADMIN_EMAIL` | بريد المدير | admin@nexthire.com |
| `ADMIN_PASSWORD` | كلمة مرور المدير | Admin123! |
| `SESSION_SECRET` | مفتاح الجلسة | nexthire-admin-secret-key |

## هيكل المشروع

- `server.js` — خادم Express + SQLite API
- `public/` — لوحة المدير (HTML/CSS/JS)
- `index.html`, `jobs.html`, `login.html`, `register.html` — الواجهة العامة
- `user-dashboard.*` / `company-dashboard.*` — لوحات المستخدمين
- `utils.js` — اتصال API والجلسة

## المميزات

- تسجيل دخول وتسجيل (شركة / باحث)
- نشر وإدارة الوظائف
- التقديم على الوظائف ومتابعة الحالة
- مهارات الباحث (قاعدة بيانات)
- إحصائيات الشركة وقبول/رفض المتقدمين
- لوحة مدير: مستخدمون، شركات، وظائف، طلبات، تقارير، تصدير CSV
