const express = require('express');
const Database = require('better-sqlite3');
const cors = require('cors');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const crypto = require('crypto');

const app = express();
const port = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';

if (isProduction) app.set('trust proxy', 1);

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'nexthire-admin-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: isProduction,
    httpOnly: true,
    maxAge: 3600000,
    sameSite: 'lax'
  }
}));
app.use(express.static('public'));

// ==================== قاعدة البيانات ====================
const dbPath = process.env.DATABASE_PATH || path.join(__dirname, 'database.db');
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
const db = new Database(dbPath);
console.log('✅ تم الاتصال بقاعدة البيانات');

// ==================== إنشاء الجداول (إذا لم تكن موجودة) ====================
db.exec(`
    CREATE TABLE IF NOT EXISTS users (
        code TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        type TEXT CHECK(type IN ('company', 'job_seeker')) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS company_profiles (
        user_code TEXT PRIMARY KEY,
        company_name TEXT NOT NULL,
        industry TEXT,
        location TEXT,
        description TEXT,
        contact_email TEXT,
        phone TEXT,
        website TEXT,
        FOREIGN KEY (user_code) REFERENCES users(code) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS jobs (
        code TEXT PRIMARY KEY,
        company_code TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        industry TEXT,
        location TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (company_code) REFERENCES users(code) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS skills (
        code TEXT PRIMARY KEY,
        name TEXT UNIQUE NOT NULL
    );

    CREATE TABLE IF NOT EXISTS user_skills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_code TEXT NOT NULL,
        skill_code TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_code, skill_code),
        FOREIGN KEY (user_code) REFERENCES users(code) ON DELETE CASCADE,
        FOREIGN KEY (skill_code) REFERENCES skills(code) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS applications (
        code TEXT PRIMARY KEY,
        user_code TEXT NOT NULL,
        job_code TEXT NOT NULL,
        status TEXT CHECK(status IN ('pending', 'accepted', 'rejected')) DEFAULT 'pending',
        applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_code, job_code),
        FOREIGN KEY (user_code) REFERENCES users(code) ON DELETE CASCADE,
        FOREIGN KEY (job_code) REFERENCES jobs(code) ON DELETE CASCADE
    );
`);

console.log('✅ تم إنشاء الجداول بنجاح');

const row = db.prepare("SELECT COUNT(*) as count FROM users").get();
if (row.count === 0) {
    console.log('📝 جاري إضافة بيانات تجريبية...');
    
    const companyCode = uuidv4();
    const hashedCompanyPassword = bcrypt.hashSync('123456', 10);
    db.prepare('INSERT INTO users (code, name, email, password, type) VALUES (?, ?, ?, ?, ?)')
        .run(companyCode, 'شركة تقنية', 'company@test.com', hashedCompanyPassword, 'company');
    db.prepare('INSERT INTO company_profiles (user_code, company_name, industry, location, description, contact_email) VALUES (?, ?, ?, ?, ?, ?)')
        .run(companyCode, 'شركة تقنية', 'تقنية المعلومات', 'القاهرة', 'شركة رائدة في مجال التكنولوجيا', 'company@test.com');
    
    const job1Code = uuidv4();
    const job2Code = uuidv4();
    db.prepare('INSERT INTO jobs (code, company_code, title, description, industry, location) VALUES (?, ?, ?, ?, ?, ?)')
        .run(job1Code, companyCode, 'مطور Frontend', 'مطلوب مطور Frontend بخبرة في React و Vue.js', 'تقنية', 'القاهرة');
    db.prepare('INSERT INTO jobs (code, company_code, title, description, industry, location) VALUES (?, ?, ?, ?, ?, ?)')
        .run(job2Code, companyCode, 'مسوق رقمي', 'مطلوب مسوق رقمي لإدارة حملات التواصل الاجتماعي', 'تسويق', 'دبي');
    
    const seekerCode = uuidv4();
    const hashedSeekerPassword = bcrypt.hashSync('123456', 10);
    db.prepare('INSERT INTO users (code, name, email, password, type) VALUES (?, ?, ?, ?, ?)')
        .run(seekerCode, 'أحمد محمد', 'user@test.com', hashedSeekerPassword, 'job_seeker');
    
    const skillsToAdd = ['JavaScript', 'React', 'Node.js', 'HTML/CSS'];
    for (const skillName of skillsToAdd) {
        let skill = db.prepare('SELECT code FROM skills WHERE name = ?').get(skillName);
        if (!skill) {
            const skillCode = uuidv4();
            db.prepare('INSERT INTO skills (code, name) VALUES (?, ?)').run(skillCode, skillName);
            db.prepare('INSERT INTO user_skills (user_code, skill_code) VALUES (?, ?)').run(seekerCode, skillCode);
        } else {
            db.prepare('INSERT INTO user_skills (user_code, skill_code) VALUES (?, ?)').run(seekerCode, skill.code);
        }
    }
    
    // إضافة بعض الطلبات التجريبية
    const appCode = uuidv4();
    db.prepare('INSERT INTO applications (code, user_code, job_code, status) VALUES (?, ?, ?, ?)')
        .run(appCode, seekerCode, job1Code, 'pending');
    
    console.log('✅ تم إضافة البيانات التجريبية بنجاح!');
    console.log('📝 حسابات تجريبية:');
    console.log('   شركة: company@test.com / 123456');
    console.log('   باحث: user@test.com / 123456');
}

function isAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  res.status(401).json({ error: 'غير مصرح. يرجى تسجيل الدخول كمدير.' });
}

app.get('/admin/login', (req, res) => {
  if (req.session && req.session.isAdmin) return res.redirect('/admin/dashboard');
  res.sendFile(path.join(__dirname, 'public', 'admin-login.html'));
});

app.get('/api/admin/session', (req, res) => {
  res.json({ loggedIn: !!(req.session && req.session.isAdmin) });
});

app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@nexthire.com';
  const adminHash = crypto.createHash('sha256').update(process.env.ADMIN_PASSWORD || 'Admin123!').digest('hex');
  const inputHash = crypto.createHash('sha256').update(password).digest('hex');
  if (email === adminEmail && inputHash === adminHash) {
    req.session.isAdmin = true;
    res.json({ success: true });
  } else {
    res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  }
});

app.post('/api/admin/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/admin/dashboard', (req, res) => {
  if (!req.session.isAdmin) return res.redirect('/admin/login');
  res.sendFile(path.join(__dirname, 'public', 'admin-dashboard.html'));
});

// ملفات لوحة المشرف (مسارات مطلقة من الجذر)
['/admin-dashboard.css', '/admin-dashboard.js'].forEach((route) => {
  const file = route.slice(1);
  app.get(route, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', file));
  });
});

app.get('/api/admin/stats', isAdmin, (req, res) => {
  try {
    const tableCheck = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='users'").get();
    if (!tableCheck) {
      return res.status(500).json({ error: 'جدول users غير موجود' });
    }
    
    const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users').get();
    const totalCompanies = db.prepare("SELECT COUNT(*) as count FROM users WHERE type = 'company'").get();
    const totalJobs = db.prepare('SELECT COUNT(*) as count FROM jobs').get();
    const totalApplications = db.prepare('SELECT COUNT(*) as count FROM applications').get();
    
    res.json({
      users: totalUsers.count,
      companies: totalCompanies.count,
      jobs: totalJobs.count,
      applications: totalApplications.count
    });
  } catch (err) {
    console.error('❌ خطأ في /api/admin/stats:', err);
    res.status(500).json({ error: err.message });
  }
});


app.get('/api/admin/users', isAdmin, (req, res) => {
  const search = req.query.search || '';
  let query = 'SELECT code as id, name, email, type, created_at FROM users';
  const params = [];
  if (search) {
    query += ' WHERE name LIKE ? OR email LIKE ?';
    params.push(`%${search}%`, `%${search}%`);
  }
  query += ' ORDER BY created_at DESC';
  try {
    const users = db.prepare(query).all(params);
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/users/:id', isAdmin, (req, res) => {
  const { id } = req.params;
  try {
    db.prepare('DELETE FROM applications WHERE user_code = ?').run(id);
    db.prepare('DELETE FROM user_skills WHERE user_code = ?').run(id);
    db.prepare('DELETE FROM company_profiles WHERE user_code = ?').run(id);
    const result = db.prepare('DELETE FROM users WHERE code = ?').run(id);
    if (result.changes === 0) return res.status(404).json({ error: 'المستخدم غير موجود' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/admin/companies', isAdmin, (req, res) => {
  const limit = req.query.limit ? parseInt(req.query.limit) : null;
  let query = `
    SELECT u.code as id, u.name as company_name, u.email, u.created_at,
           cp.industry, cp.location, cp.description, cp.phone, cp.website
    FROM users u
    LEFT JOIN company_profiles cp ON u.code = cp.user_code
    WHERE u.type = 'company'
    ORDER BY u.created_at DESC
  `;
  if (limit) query += ` LIMIT ${limit}`;
  try {
    const companies = db.prepare(query).all();
    res.json(companies);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/companies/:id', isAdmin, (req, res) => {
  const { id } = req.params;
  try {
    const jobs = db.prepare('SELECT code FROM jobs WHERE company_code = ?').all(id);
    for (const job of jobs) db.prepare('DELETE FROM applications WHERE job_code = ?').run(job.code);
    db.prepare('DELETE FROM jobs WHERE company_code = ?').run(id);
    db.prepare('DELETE FROM company_profiles WHERE user_code = ?').run(id);
    const result = db.prepare("DELETE FROM users WHERE code = ? AND type = 'company'").run(id);
    if (result.changes === 0) return res.status(404).json({ error: 'الشركة غير موجودة' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/admin/jobs', isAdmin, (req, res) => {
  try {
    const jobs = db.prepare(`
      SELECT j.code as id, j.title, j.description, j.industry, j.location, j.created_at,
             u.name as company_name, j.company_code
      FROM jobs j
      JOIN users u ON j.company_code = u.code
      ORDER BY j.created_at DESC
    `).all();
    res.json(jobs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/jobs', isAdmin, (req, res) => {
  const { title, description, company_code, industry, location } = req.body;
  if (!title || !description || !company_code) {
    return res.status(400).json({ error: 'العنوان والوصف ورمز الشركة مطلوبة' });
  }
  try {
    const jobCode = uuidv4();
    db.prepare(`INSERT INTO jobs (code, company_code, title, description, industry, location) VALUES (?, ?, ?, ?, ?, ?)`)
      .run(jobCode, company_code, title, description, industry || null, location || null);
    res.json({ id: jobCode, success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/jobs/:id', isAdmin, (req, res) => {
  const { id } = req.params;
  const { title, description, industry, location } = req.body;
  try {
    const result = db.prepare(`UPDATE jobs SET title = ?, description = ?, industry = ?, location = ? WHERE code = ?`)
      .run(title, description, industry || null, location || null, id);
    if (result.changes === 0) return res.status(404).json({ error: 'الوظيفة غير موجودة' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/jobs/:id', isAdmin, (req, res) => {
  const { id } = req.params;
  try {
    db.prepare('DELETE FROM applications WHERE job_code = ?').run(id);
    const result = db.prepare('DELETE FROM jobs WHERE code = ?').run(id);
    if (result.changes === 0) return res.status(404).json({ error: 'الوظيفة غير موجودة' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/admin/applications', isAdmin, (req, res) => {
  const { status, limit } = req.query;
  let query = `
    SELECT a.code as id, a.user_code, a.job_code, a.status, a.applied_at,
           u.name as user_name, u.email as user_email,
           j.title as job_title,
           comp.name as company_name
    FROM applications a
    JOIN users u ON a.user_code = u.code
    JOIN jobs j ON a.job_code = j.code
    JOIN users comp ON j.company_code = comp.code
  `;
  const params = [];
  if (status && ['pending', 'accepted', 'rejected'].includes(status)) {
    query += ' WHERE a.status = ?';
    params.push(status);
  }
  query += ' ORDER BY a.applied_at DESC';
  if (limit) query += ` LIMIT ${parseInt(limit)}`;
  try {
    const apps = db.prepare(query).all(params);
    res.json(apps);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/applications/:id/status', isAdmin, (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  if (!['accepted', 'rejected', 'pending'].includes(status)) {
    return res.status(400).json({ error: 'حالة غير صالحة' });
  }
  try {
    const result = db.prepare('UPDATE applications SET status = ? WHERE code = ?').run(status, id);
    if (result.changes === 0) return res.status(404).json({ error: 'الطلب غير موجود' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/admin/companies-list', isAdmin, (req, res) => {
  try {
    const companies = db.prepare("SELECT code as id, name FROM users WHERE type = 'company' ORDER BY name").all();
    res.json(companies);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== APIs المشروع الأصلي (بنفس الشكل) ====================
app.get('/api/users', (req, res) => {
  try {
    const rows = db.prepare('SELECT code, name, email, type, created_at FROM users ORDER BY created_at DESC').all();
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/register', async (req, res) => {
  const { name, email, password, type, company_name, contact_email } = req.body;
  if (!name || !email || !password || !type) return res.status(400).json({ error: 'جميع الحقول المطلوبة غير موجودة' });
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const userCode = uuidv4();
    db.prepare('INSERT INTO users (code, name, email, password, type) VALUES (?, ?, ?, ?, ?)').run(userCode, name, email, hashedPassword, type);
    if (type === 'company') {
      db.prepare('INSERT INTO company_profiles (user_code, company_name, contact_email) VALUES (?, ?, ?)').run(userCode, company_name || name, contact_email || email);
    }
    res.json({ success: true, message: 'تم إنشاء الحساب بنجاح' });
  } catch (err) {
    if (err.message.includes('UNIQUE')) return res.status(400).json({ error: 'البريد الإلكتروني موجود مسبقاً' });
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/users/:user_code', (req, res) => {
  const { user_code } = req.params;
  const { name } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'الاسم مطلوب' });
  try {
    const result = db.prepare('UPDATE users SET name = ? WHERE code = ?').run(name.trim(), user_code);
    if (result.changes === 0) return res.status(404).json({ error: 'المستخدم غير موجود' });
    const user = db.prepare('SELECT code, name, email, type, created_at FROM users WHERE code = ?').get(user_code);
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'البريد الإلكتروني وكلمة المرور مطلوبة' });
  try {
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user) return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
    const { password: _, ...userWithoutPassword } = user;
    res.json({ success: true, user: userWithoutPassword });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/jobs', (req, res) => {
  try {
    const rows = db.prepare(`SELECT j.*, u.name as company_name FROM jobs j JOIN users u ON j.company_code = u.code ORDER BY j.created_at DESC`).all();
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/jobs', (req, res) => {
  const { company_code, title, description, industry, location } = req.body;
  if (!company_code || !title || !description) return res.status(400).json({ error: 'بيانات الوظيفة غير مكتملة' });
  try {
    const jobCode = uuidv4();
    db.prepare(`INSERT INTO jobs (code, company_code, title, description, industry, location) VALUES (?, ?, ?, ?, ?, ?)`)
      .run(jobCode, company_code, title, description, industry, location);
    res.json({ success: true, job_code: jobCode });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/jobs/:job_code', (req, res) => {
  const { job_code } = req.params;
  try {
    db.prepare('DELETE FROM applications WHERE job_code = ?').run(job_code);
    const result = db.prepare('DELETE FROM jobs WHERE code = ?').run(job_code);
    if (result.changes === 0) return res.status(404).json({ error: 'الوظيفة غير موجودة' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/applications', (req, res) => {
  const { user_code, job_code } = req.body;
  const appCode = uuidv4();
  try {
    db.prepare(`INSERT INTO applications (code, user_code, job_code) VALUES (?, ?, ?)`).run(appCode, user_code, job_code);
    res.json({ success: true });
  } catch (err) {
    if (err.message.includes('UNIQUE')) return res.status(400).json({ error: 'سبق لك التقديم على هذه الوظيفة' });
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/company-applications/:company_code', (req, res) => {
  const { company_code } = req.params;
  try {
    const rows = db.prepare(`SELECT a.*, u.name as user_name, u.email as user_email, j.title as job_title FROM applications a JOIN jobs j ON a.job_code = j.code JOIN users u ON a.user_code = u.code WHERE j.company_code = ? ORDER BY a.applied_at DESC`).all(company_code);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/applications/:app_code', (req, res) => {
  const { app_code } = req.params;
  const { status } = req.body;
  if (!['pending', 'accepted', 'rejected'].includes(status)) return res.status(400).json({ error: 'حالة غير صالحة' });
  try {
    db.prepare('UPDATE applications SET status = ? WHERE code = ?').run(status, app_code);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/company-profile/:user_code', (req, res) => {
  const { user_code } = req.params;
  try {
    const row = db.prepare('SELECT * FROM company_profiles WHERE user_code = ?').get(user_code);
    res.json(row || {});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/company-profile/:user_code', (req, res) => {
  const { user_code } = req.params;
  const { company_name, industry, location, description, contact_email, phone, website } = req.body;
  try {
    db.prepare(`UPDATE company_profiles SET company_name = ?, industry = ?, location = ?, description = ?, contact_email = ?, phone = ?, website = ? WHERE user_code = ?`)
      .run(company_name, industry, location, description, contact_email, phone, website, user_code);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/company-jobs/:company_code', (req, res) => {
  const { company_code } = req.params;
  try {
    const rows = db.prepare('SELECT * FROM jobs WHERE company_code = ? ORDER BY created_at DESC').all(company_code);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/user-applications/:user_code', (req, res) => {
  const { user_code } = req.params;
  try {
    const rows = db.prepare(`SELECT a.*, j.title as job_title, u.name as company_name FROM applications a JOIN jobs j ON a.job_code = j.code JOIN users u ON j.company_code = u.code WHERE a.user_code = ? ORDER BY a.applied_at DESC`).all(user_code);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/user-skills/:user_code', (req, res) => {
  const { user_code } = req.params;
  try {
    const rows = db.prepare(`SELECT s.code, s.name FROM user_skills us JOIN skills s ON us.skill_code = s.code WHERE us.user_code = ? ORDER BY s.name ASC`).all(user_code);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/user-skills/:user_code', (req, res) => {
  const { user_code } = req.params;
  const { skills } = req.body;
  if (!skills || !Array.isArray(skills)) return res.status(400).json({ error: 'المهارات يجب أن تكون مصفوفة' });
  try {
    db.prepare('DELETE FROM user_skills WHERE user_code = ?').run(user_code);
    for (const skillName of skills) {
      if (!skillName || !skillName.trim()) continue;
      let skill = db.prepare('SELECT code FROM skills WHERE name = ?').get(skillName.trim());
      if (skill) {
        db.prepare('INSERT INTO user_skills (user_code, skill_code) VALUES (?, ?)').run(user_code, skill.code);
      } else {
        const skillCode = uuidv4();
        db.prepare('INSERT INTO skills (code, name) VALUES (?, ?)').run(skillCode, skillName.trim());
        db.prepare('INSERT INTO user_skills (user_code, skill_code) VALUES (?, ?)').run(user_code, skillCode);
      }
    }
    const newSkills = db.prepare(`SELECT s.code, s.name FROM user_skills us JOIN skills s ON us.skill_code = s.code WHERE us.user_code = ? ORDER BY s.name ASC`).all(user_code);
    res.json({ success: true, skills: newSkills });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== تقديم الملفات الثابتة ====================
app.use(express.static(path.join(__dirname)));

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/admin')) return next();
  if (path.extname(req.path)) return next();
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(port, '0.0.0.0', () => {
  console.log(`\n========================================`);
  console.log(`🚀 الخادم يعمل على http://localhost:${port}`);
  console.log(`========================================`);
  console.log(`📝 حسابات تجريبية:`);
  console.log(`   شركة: company@test.com / 123456`);
  console.log(`   باحث: user@test.com / 123456`);
  console.log(`   مدير: admin@nexthire.com / Admin123!`);
  console.log(`========================================\n`);
});