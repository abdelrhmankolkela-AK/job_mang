const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const out = path.join(root, 'docs');

const copyFiles = [
  'index.html', 'login.html', 'register.html', 'jobs.html',
  'user-dashboard.html', 'company-dashboard.html',
  'index.js', 'login.js', 'register.js', 'jobs.js', 'auth.js',
  'user-dashboard.js', 'company-dashboard.js', 'utils.js', 'config.js', 'demo.js',
  'style.css'
];

const copyFromPublic = [
  'admin-login.html',
  'admin-dashboard.html',
  'admin-dashboard.js',
  'admin-dashboard.css'
];

function rm(dir) {
  if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
}

function cp(src, dest) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(src, dest);
}

rm(out);
fs.mkdirSync(out, { recursive: true });

for (const f of copyFiles) {
  cp(path.join(root, f), path.join(out, f));
}
for (const f of copyFromPublic) {
  cp(path.join(root, 'public', f), path.join(out, f));
}

fs.writeFileSync(path.join(out, '.nojekyll'), '');
console.log('✅ Built docs/ for GitHub Pages');
