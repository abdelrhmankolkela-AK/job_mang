let currentSection = 'dashboard';
let currentUserFilter = '';
let companiesList = [];

const PAGE_TITLES = {
    dashboard: 'Dashboard',
    users: 'Users',
    companies: 'Companies',
    jobs: 'Jobs',
    applications: 'Applications',
    reports: 'Reports',
    settings: 'Settings'
};

const fetchOpts = { credentials: 'include' };

function adminDemoFetch(url, options = {}) {
    const method = (options.method || 'GET').toUpperCase();
    let users = JSON.parse(localStorage.getItem('jobportal_users') || '[]');
    let jobs = JSON.parse(localStorage.getItem('jobportal_jobs') || '[]');
    let apps = JSON.parse(localStorage.getItem('jobportal_applications') || '[]');
    const companies = users.filter(u => u.type === 'company');

    const persist = () => {
        localStorage.setItem('jobportal_users', JSON.stringify(users));
        localStorage.setItem('jobportal_jobs', JSON.stringify(jobs));
        localStorage.setItem('jobportal_applications', JSON.stringify(apps));
    };

    if (method === 'DELETE') {
        const userId = url.match(/\/users\/([^/?]+)/)?.[1];
        const companyId = url.match(/\/companies\/([^/?]+)/)?.[1];
        const jobId = url.match(/\/jobs\/([^/?]+)/)?.[1];
        if (userId) {
            users = users.filter(u => u.code !== userId);
            apps = apps.filter(a => a.user_code !== userId);
            persist();
            return { success: true };
        }
        if (companyId) {
            const jobCodes = jobs.filter(j => j.company_code === companyId).map(j => j.code);
            users = users.filter(u => u.code !== companyId);
            jobs = jobs.filter(j => j.company_code !== companyId);
            apps = apps.filter(a => !jobCodes.includes(a.job_code));
            persist();
            return { success: true };
        }
        if (jobId) {
            jobs = jobs.filter(j => j.code !== jobId);
            apps = apps.filter(a => a.job_code !== jobId);
            persist();
            return { success: true };
        }
        return { success: true };
    }

    if (method === 'PUT' || method === 'POST') {
        const statusMatch = url.match(/\/applications\/([^/?]+)\/status/);
        if (statusMatch && method === 'PUT') {
            const body = options.body ? JSON.parse(options.body) : {};
            const id = statusMatch[1];
            apps = apps.map(a => a.code === id ? { ...a, status: body.status } : a);
            persist();
            return { success: true };
        }
        return { success: true, id: 'demo-id' };
    }

    if (url.includes('/stats')) {
        return { users: users.length, companies: companies.length, jobs: jobs.length, applications: apps.length };
    }
    if (url.includes('/companies-list')) {
        return companies.map(c => ({ id: c.code, name: c.name }));
    }
    if (url.includes('/companies')) {
        const data = JSON.parse(localStorage.getItem('jobportal_companies') || '{}');
        return companies.map(c => ({
            id: c.code, company_name: data[c.code]?.company_name || c.name, email: c.email,
            industry: data[c.code]?.industry, location: data[c.code]?.location, created_at: c.created_at
        }));
    }
    if (url.includes('/users')) {
        return users.map(({ password, ...u }) => ({ id: u.code, name: u.name, email: u.email, type: u.type, created_at: u.created_at }));
    }
    if (url.includes('/jobs')) {
        return jobs.map(j => ({ id: j.code, title: j.title, description: j.description, industry: j.industry, location: j.location, created_at: j.created_at, company_name: j.company_name, company_code: j.company_code }));
    }
    if (url.includes('/applications')) {
        return apps.map(a => ({
            id: a.code, user_code: a.user_code, job_code: a.job_code, status: a.status, applied_at: a.applied_at,
            user_name: a.user_name, user_email: a.user_email, job_title: a.job_title, company_name: a.company_name
        }));
    }
    return {};
}

async function fetchAPI(url, options = {}) {
    if (sessionStorage.getItem('adminDemo') === '1') {
        return adminDemoFetch(url, options);
    }
    const res = await fetch(url, { ...fetchOpts, ...options });
    if (res.status === 401) {
        window.location.href = '/admin/login';
        throw new Error('Unauthorized');
    }
    const text = await res.text();
    let data;
    try {
        data = JSON.parse(text);
    } catch {
        throw new Error('استجابة غير صالحة من الخادم');
    }
    if (!res.ok) throw new Error(data.error || 'حدث خطأ');
    return data;
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m]));
}

function formatNum(n) {
    return Number(n || 0).toLocaleString('en-US');
}

function formatDate(d) {
    return d ? new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '-';
}

function statusLabel(status) {
    return { pending: 'Pending', accepted: 'Accepted', rejected: 'Rejected' }[status] || status;
}

function statusPill(status) {
    const label = { pending: 'Pending', accepted: 'Accepted', rejected: 'Rejected', approved: 'Approved' }[status] || status;
    return `<span class="status-pill ${status}">${label}</span>`;
}

function companyInitials(name) {
    return (name || 'C').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function companyRegStatus(c) {
    return (c.industry && c.location) ? 'approved' : 'pending';
}

function sparkline(color, seed) {
    const pts = [];
    let y = 18;
    let s = Math.max(1, seed);
    for (let i = 0; i < 7; i++) {
        y = Math.max(4, Math.min(26, y + ((s % 5) - 2)));
        pts.push(`${i * 12},${y}`);
        s = Math.floor(s * 1.7) + 3;
    }
    return `<svg class="sparkline" viewBox="0 0 72 30" preserveAspectRatio="none" aria-hidden="true">
        <polyline fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" points="${pts.join(' ')}"/>
    </svg>`;
}

function metricCard({ color, icon, label, value, sub, stroke, seed }) {
    return `
        <div class="metric-card">
            <div class="metric-left">
                <div class="metric-icon ${color}"><i class="fas ${icon}"></i></div>
                <div>
                    <p class="metric-label">${label}</p>
                    <p class="metric-value">${formatNum(value)}</p>
                    <p class="metric-sub">${sub}</p>
                </div>
            </div>
            ${sparkline(stroke, seed)}
        </div>`;
}

function showLoading() {
    document.getElementById('dynamicContent').innerHTML = `
        <div class="loading-state"><span class="spinner"></span><p>جاري التحميل...</p></div>`;
}

function setPageTitle(section) {
    const el = document.getElementById('pageTitle');
    if (el) el.textContent = PAGE_TITLES[section] || 'Dashboard';
}

function setActiveNav(section, filter = '') {
    document.querySelectorAll('.menu-link[data-section], .submenu-link').forEach(el => el.classList.remove('active'));
    if (section === 'users' && filter) {
        document.querySelector(`.submenu-link[data-filter="${filter}"]`)?.classList.add('active');
        document.getElementById('usersMenuGroup')?.classList.add('open');
        document.getElementById('usersMenuToggle')?.setAttribute('aria-expanded', 'true');
    } else {
        document.querySelector(`.menu-link[data-section="${section}"]`)?.classList.add('active');
    }
}

function toggleToolbar(section) {
    const toolbar = document.getElementById('contentToolbar');
    if (toolbar) toolbar.classList.toggle('hidden', section !== 'users');
}

// ==================== Dashboard ====================
async function loadDashboard() {
    showLoading();
    try {
        const stats = await fetchAPI('/api/admin/stats');
        const recentApps = await fetchAPI('/api/admin/applications?limit=5');
        const recentCompanies = await fetchAPI('/api/admin/companies?limit=5');
        const jobSeekers = Math.max(0, stats.users - stats.companies);

        document.getElementById('dynamicContent').innerHTML = `
            <div class="metrics-row">
                ${metricCard({ color: 'purple', icon: 'fa-users', label: 'Total Users', value: jobSeekers, sub: 'Job Seekers', stroke: '#7c3aed', seed: jobSeekers })}
                ${metricCard({ color: 'green', icon: 'fa-building', label: 'Total Companies', value: stats.companies, sub: 'Registered Companies', stroke: '#16a34a', seed: stats.companies })}
                ${metricCard({ color: 'orange', icon: 'fa-briefcase', label: 'Total Jobs', value: stats.jobs, sub: 'Published Jobs', stroke: '#ea580c', seed: stats.jobs })}
                ${metricCard({ color: 'blue', icon: 'fa-file-alt', label: 'Total Applications', value: stats.applications, sub: 'All Applications', stroke: '#2563eb', seed: stats.applications })}
            </div>
            <div class="widgets-row">
                <div class="widget-card">
                    <div class="widget-header">
                        <h3>Recent Job Applications</h3>
                        <a href="#" class="view-all" data-goto="applications">View All</a>
                    </div>
                    <div class="widget-table-wrap">
                        <table class="widget-table">
                            <thead><tr><th>Applicant</th><th>Company</th><th>Date</th><th>Status</th></tr></thead>
                            <tbody>${renderRecentApps(recentApps)}</tbody>
                        </table>
                    </div>
                </div>
                <div class="widget-card">
                    <div class="widget-header">
                        <h3>Recent Companies</h3>
                        <a href="#" class="view-all" data-goto="companies">View All</a>
                    </div>
                    <div class="widget-table-wrap">
                        <table class="widget-table">
                            <thead><tr><th>Company</th><th>Date</th><th>Status</th></tr></thead>
                            <tbody>${renderRecentCompanies(recentCompanies)}</tbody>
                        </table>
                    </div>
                </div>
            </div>`;

        bindViewAllLinks();
    } catch (err) {
        document.getElementById('dynamicContent').innerHTML = `<div class="loading-state error-msg">${escapeHtml(err.message)}</div>`;
    }
}

function renderRecentApps(apps) {
    if (!apps.length) return '<tr><td colspan="4">لا توجد طلبات حديثة</td></tr>';
    return apps.map(app => `
        <tr>
            <td>
                <div class="applicant-cell">
                    <div class="name">${escapeHtml(app.user_name)}</div>
                    <div class="role">${escapeHtml(app.job_title)}</div>
                </div>
            </td>
            <td>${escapeHtml(app.company_name)}</td>
            <td>${formatDate(app.applied_at)}</td>
            <td>${statusPill(app.status)}</td>
        </tr>`).join('');
}

function renderRecentCompanies(companies) {
    if (!companies.length) return '<tr><td colspan="3">لا توجد شركات حديثة</td></tr>';
    return companies.map(c => {
        const st = companyRegStatus(c);
        return `
        <tr>
            <td>
                <div class="company-cell">
                    <span class="company-logo">${companyInitials(c.company_name)}</span>
                    <span>${escapeHtml(c.company_name)}</span>
                </div>
            </td>
            <td>${formatDate(c.created_at)}</td>
            <td>${statusPill(st)}</td>
        </tr>`;
    }).join('');
}

function bindViewAllLinks() {
    document.querySelectorAll('[data-goto]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            switchSection(link.dataset.goto);
        });
    });
}

// ==================== Users ====================
async function loadUsers(search = '', typeFilter = '') {
    showLoading();
    try {
        const url = search ? `/api/admin/users?search=${encodeURIComponent(search)}` : '/api/admin/users';
        let users = await fetchAPI(url);
        if (typeFilter) users = users.filter(u => u.type === typeFilter);

        const filterLabel = typeFilter === 'job_seeker' ? 'باحثون عن عمل' : typeFilter === 'company' ? 'شركات' : 'كل المستخدمين';

        document.getElementById('dynamicContent').innerHTML = `
            <div class="page-card">
                <div class="page-card-header">
                    <h2>${filterLabel} (${users.length})</h2>
                </div>
                <div class="data-table">
                    <table>
                        <thead><tr><th>Name</th><th>Email</th><th>Type</th><th>Registered</th><th>Action</th></tr></thead>
                        <tbody>
                        ${users.map(u => `
                            <tr>
                                <td>${escapeHtml(u.name)}</td>
                                <td>${escapeHtml(u.email)}</td>
                                <td><span class="badge ${u.type === 'company' ? 'badge-company' : 'badge-seeker'}">${u.type === 'company' ? 'Company' : 'Job Seeker'}</span></td>
                                <td>${formatDate(u.created_at)}</td>
                                <td><button class="btn btn-danger" onclick="deleteUser('${u.id}')">Delete</button></td>
                            </tr>`).join('') || '<tr><td colspan="5">لا يوجد مستخدمون</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>`;
    } catch (err) {
        document.getElementById('dynamicContent').innerHTML = `<div class="loading-state error-msg">${escapeHtml(err.message)}</div>`;
    }
}

window.deleteUser = async (id) => {
    if (!confirm('هل أنت متأكد من حذف هذا المستخدم؟')) return;
    try {
        await fetchAPI(`/api/admin/users/${id}`, { method: 'DELETE' });
        loadUsers(document.getElementById('globalSearch')?.value || '', currentUserFilter);
    } catch (err) {
        alert(err.message);
    }
};

// ==================== Companies ====================
async function loadCompanies() {
    showLoading();
    try {
        const companies = await fetchAPI('/api/admin/companies');
        document.getElementById('dynamicContent').innerHTML = `
            <div class="page-card">
                <div class="page-card-header"><h2>Companies (${companies.length})</h2></div>
                <div class="data-table">
                    <table>
                        <thead><tr><th>Company</th><th>Email</th><th>Industry</th><th>Location</th><th>Date</th><th>Status</th><th>Action</th></tr></thead>
                        <tbody>
                        ${companies.map(c => `
                            <tr>
                                <td>
                                    <div class="company-cell">
                                        <span class="company-logo">${companyInitials(c.company_name)}</span>
                                        <span>${escapeHtml(c.company_name)}</span>
                                    </div>
                                </td>
                                <td>${escapeHtml(c.email)}</td>
                                <td>${escapeHtml(c.industry || '-')}</td>
                                <td>${escapeHtml(c.location || '-')}</td>
                                <td>${formatDate(c.created_at)}</td>
                                <td>${statusPill(companyRegStatus(c))}</td>
                                <td><button class="btn btn-danger" onclick="deleteCompany('${c.id}')">Delete</button></td>
                            </tr>`).join('') || '<tr><td colspan="7">لا توجد شركات</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>`;
    } catch (err) {
        document.getElementById('dynamicContent').innerHTML = `<div class="loading-state error-msg">${escapeHtml(err.message)}</div>`;
    }
}

window.deleteCompany = async (id) => {
    if (!confirm('سيتم حذف جميع وظائف هذه الشركة أيضاً. متابعة؟')) return;
    try {
        await fetchAPI(`/api/admin/companies/${id}`, { method: 'DELETE' });
        loadCompanies();
    } catch (err) {
        alert(err.message);
    }
};

// ==================== Jobs ====================
async function loadJobs() {
    showLoading();
    try {
        const jobs = await fetchAPI('/api/admin/jobs');
        companiesList = await fetchAPI('/api/admin/companies-list');
        document.getElementById('dynamicContent').innerHTML = `
            <div class="page-card">
                <div class="page-card-header">
                    <h2>Jobs (${jobs.length})</h2>
                    <button class="btn btn-primary" onclick="showJobModal()">+ Add Job</button>
                </div>
                <div class="data-table">
                    <table>
                        <thead><tr><th>Title</th><th>Company</th><th>Industry</th><th>Location</th><th>Date</th><th>Actions</th></tr></thead>
                        <tbody>
                        ${jobs.map(j => `
                            <tr>
                                <td>${escapeHtml(j.title)}</td>
                                <td>${escapeHtml(j.company_name)}</td>
                                <td>${escapeHtml(j.industry || '-')}</td>
                                <td>${escapeHtml(j.location || '-')}</td>
                                <td>${formatDate(j.created_at)}</td>
                                <td>
                                    <button class="btn btn-warning" onclick="editJob('${j.id}')">Edit</button>
                                    <button class="btn btn-danger" onclick="deleteJob('${j.id}')">Delete</button>
                                </td>
                            </tr>`).join('') || '<tr><td colspan="6">لا توجد وظائف</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="jobModal" class="modal"><div class="modal-content" id="jobModalContent"></div></div>`;
    } catch (err) {
        document.getElementById('dynamicContent').innerHTML = `<div class="loading-state error-msg">${escapeHtml(err.message)}</div>`;
    }
}

window.showJobModal = (job = null) => {
    const isEdit = !!job;
    const modalDiv = document.getElementById('jobModal');
    const contentDiv = document.getElementById('jobModalContent');
    if (!modalDiv || !contentDiv) return;
    const companiesOptions = companiesList.map(c =>
        `<option value="${c.id}" ${job && job.company_code === c.id ? 'selected' : ''}>${escapeHtml(c.name)}</option>`
    ).join('');
    contentDiv.innerHTML = `
        <h3>${isEdit ? 'Edit Job' : 'Add New Job'}</h3>
        <form id="jobForm">
            <div class="input-group"><label>Title</label><input type="text" id="title" value="${isEdit ? escapeHtml(job.title) : ''}" required></div>
            <div class="input-group"><label>Description</label><textarea id="description" rows="4" required>${isEdit ? escapeHtml(job.description) : ''}</textarea></div>
            <div class="input-group"><label>Company</label><select id="company_code" ${isEdit ? 'disabled' : ''} required><option value="">Select company</option>${companiesOptions}</select></div>
            <div class="input-group"><label>Industry</label><input type="text" id="industry" value="${isEdit ? escapeHtml(job.industry || '') : ''}"></div>
            <div class="input-group"><label>Location</label><input type="text" id="location" value="${isEdit ? escapeHtml(job.location || '') : ''}"></div>
            <div class="modal-actions">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="button" class="btn" onclick="closeModal()">Cancel</button>
            </div>
        </form>`;
    modalDiv.style.display = 'flex';
    document.getElementById('jobForm').onsubmit = async (e) => {
        e.preventDefault();
        const data = {
            title: document.getElementById('title').value.trim(),
            description: document.getElementById('description').value.trim(),
            company_code: isEdit ? job.company_code : document.getElementById('company_code').value,
            industry: document.getElementById('industry').value.trim(),
            location: document.getElementById('location').value.trim()
        };
        try {
            if (isEdit) {
                await fetchAPI(`/api/admin/jobs/${job.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
            } else {
                await fetchAPI('/api/admin/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
            }
            closeModal();
            loadJobs();
        } catch (err) {
            alert(err.message);
        }
    };
};

window.editJob = async (id) => {
    try {
        const jobs = await fetchAPI('/api/admin/jobs');
        const job = jobs.find(j => j.id === id);
        if (job) showJobModal(job);
    } catch (err) {
        alert(err.message);
    }
};

window.deleteJob = async (id) => {
    if (!confirm('حذف الوظيفة سيحذف جميع الطلبات المرتبطة. متابعة؟')) return;
    try {
        await fetchAPI(`/api/admin/jobs/${id}`, { method: 'DELETE' });
        loadJobs();
    } catch (err) {
        alert(err.message);
    }
};

window.closeModal = () => {
    const modal = document.getElementById('jobModal');
    if (modal) modal.style.display = 'none';
};

// ==================== Applications ====================
async function loadApplications(status = '') {
    showLoading();
    try {
        const url = status ? `/api/admin/applications?status=${status}` : '/api/admin/applications';
        const apps = await fetchAPI(url);
        document.getElementById('dynamicContent').innerHTML = `
            <div class="page-card">
                <div class="page-card-header">
                    <h2>Applications (${apps.length})</h2>
                    <select id="appFilter" class="filter-select">
                        <option value="" ${status === '' ? 'selected' : ''}>All</option>
                        <option value="pending" ${status === 'pending' ? 'selected' : ''}>Pending</option>
                        <option value="accepted" ${status === 'accepted' ? 'selected' : ''}>Accepted</option>
                        <option value="rejected" ${status === 'rejected' ? 'selected' : ''}>Rejected</option>
                    </select>
                </div>
                <div class="data-table">
                    <table>
                        <thead><tr><th>Applicant</th><th>Job</th><th>Company</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
                        <tbody>
                        ${apps.map(a => `
                            <tr>
                                <td>
                                    <div class="applicant-cell">
                                        <div class="name">${escapeHtml(a.user_name)}</div>
                                        <div class="role">${escapeHtml(a.user_email)}</div>
                                    </div>
                                </td>
                                <td>${escapeHtml(a.job_title)}</td>
                                <td>${escapeHtml(a.company_name)}</td>
                                <td>${statusPill(a.status)}</td>
                                <td>${formatDate(a.applied_at)}</td>
                                <td>
                                    ${a.status !== 'accepted' ? `<button class="btn btn-success" onclick="updateAppStatus('${a.id}', 'accepted')">Accept</button>` : ''}
                                    ${a.status !== 'rejected' ? `<button class="btn btn-danger" onclick="updateAppStatus('${a.id}', 'rejected')">Reject</button>` : ''}
                                </td>
                            </tr>`).join('') || '<tr><td colspan="6">لا توجد طلبات</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>`;
        document.getElementById('appFilter')?.addEventListener('change', (e) => loadApplications(e.target.value));
    } catch (err) {
        document.getElementById('dynamicContent').innerHTML = `<div class="loading-state error-msg">${escapeHtml(err.message)}</div>`;
    }
}

window.updateAppStatus = async (id, status) => {
    try {
        await fetchAPI(`/api/admin/applications/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status })
        });
        loadApplications(document.getElementById('appFilter')?.value || '');
    } catch (err) {
        alert(err.message);
    }
};

// ==================== Reports ====================
async function loadReports() {
    showLoading();
    try {
        const stats = await fetchAPI('/api/admin/stats');
        const apps = await fetchAPI('/api/admin/applications');
        const pending = apps.filter(a => a.status === 'pending').length;
        const accepted = apps.filter(a => a.status === 'accepted').length;
        const rejected = apps.filter(a => a.status === 'rejected').length;
        const acceptRate = apps.length ? Math.round((accepted / apps.length) * 100) : 0;

        document.getElementById('dynamicContent').innerHTML = `
            <div class="metrics-row">
                ${metricCard({ color: 'blue', icon: 'fa-percent', label: 'Acceptance Rate', value: acceptRate, sub: 'Percent', stroke: '#2563eb', seed: acceptRate })}
                ${metricCard({ color: 'orange', icon: 'fa-clock', label: 'Pending', value: pending, sub: 'Applications', stroke: '#ea580c', seed: pending })}
                ${metricCard({ color: 'green', icon: 'fa-check', label: 'Accepted', value: accepted, sub: 'Applications', stroke: '#16a34a', seed: accepted })}
                ${metricCard({ color: 'purple', icon: 'fa-times', label: 'Rejected', value: rejected, sub: 'Applications', stroke: '#7c3aed', seed: rejected })}
            </div>
            <div class="page-card">
                <div class="page-card-header">
                    <h2>Platform Summary</h2>
                    <button class="btn btn-primary" onclick="exportCsv()">Export Users CSV</button>
                </div>
                <div class="reports-grid">
                    <div class="report-stat"><div class="num">${formatNum(stats.users)}</div><div>Total Accounts</div></div>
                    <div class="report-stat"><div class="num">${formatNum(stats.companies)}</div><div>Companies</div></div>
                    <div class="report-stat"><div class="num">${formatNum(stats.jobs)}</div><div>Jobs</div></div>
                    <div class="report-stat"><div class="num">${formatNum(stats.applications)}</div><div>Applications</div></div>
                </div>
            </div>`;
    } catch (err) {
        document.getElementById('dynamicContent').innerHTML = `<div class="loading-state error-msg">${escapeHtml(err.message)}</div>`;
    }
}

window.exportCsv = async () => {
    try {
        const users = await fetchAPI('/api/admin/users');
        const header = 'Name,Email,Type,Registered\n';
        const rows = users.map(u =>
            `"${(u.name || '').replace(/"/g, '""')}","${u.email}","${u.type === 'company' ? 'Company' : 'Job Seeker'}","${u.created_at || ''}"`
        ).join('\n');
        const blob = new Blob(['\ufeff' + header + rows], { type: 'text/csv;charset=utf-8;' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `nexthire-users-${new Date().toISOString().slice(0, 10)}.csv`;
        a.click();
    } catch (err) {
        alert(err.message);
    }
};

function loadSettings() {
    document.getElementById('dynamicContent').innerHTML = `
        <div class="page-card">
            <div class="page-card-header"><h2>Settings</h2></div>
            <ul class="report-list">
                <li>Admin email: <code>admin@nexthire.com</code></li>
                <li>Default password: <code>Admin123!</code></li>
            </ul>
            <p class="hint">Change via environment variables: ADMIN_EMAIL, ADMIN_PASSWORD, SESSION_SECRET</p>
        </div>`;
}

function switchSection(section, filter = '') {
    currentSection = section;
    currentUserFilter = filter;
    setPageTitle(section);
    setActiveNav(section, filter);
    toggleToolbar(section);
    closeSidebar();

    const search = document.getElementById('globalSearch');
    if (search && section !== 'users') search.value = '';

    if (section === 'dashboard') loadDashboard();
    else if (section === 'users') loadUsers(search?.value || '', filter);
    else if (section === 'companies') loadCompanies();
    else if (section === 'jobs') loadJobs();
    else if (section === 'applications') loadApplications();
    else if (section === 'reports') loadReports();
    else if (section === 'settings') loadSettings();
}

function closeSidebar() {
    document.getElementById('sidebar')?.classList.remove('open');
    document.getElementById('sidebarOverlay')?.classList.remove('visible');
}

document.getElementById('logoutBtn')?.addEventListener('click', async (e) => {
    e.preventDefault();
    if (sessionStorage.getItem('adminDemo') === '1') {
        sessionStorage.removeItem('adminDemo');
    } else {
        await fetch('/api/admin/logout', { method: 'POST', credentials: 'include' });
    }
    window.location.href = '/admin/login';
});

document.querySelectorAll('.menu-link[data-section]').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        switchSection(btn.dataset.section);
    });
});

document.querySelectorAll('.submenu-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        switchSection('users', link.dataset.filter || '');
    });
});

document.getElementById('usersMenuToggle')?.addEventListener('click', () => {
    const group = document.getElementById('usersMenuGroup');
    const open = group.classList.toggle('open');
    document.getElementById('usersMenuToggle').setAttribute('aria-expanded', open);
});

document.querySelector('.menu-link[data-section="dashboard"]')?.addEventListener('click', (e) => {
    e.preventDefault();
    switchSection('dashboard');
});

let searchTimeout;
document.getElementById('globalSearch')?.addEventListener('input', (e) => {
    if (currentSection !== 'users') return;
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => loadUsers(e.target.value, currentUserFilter), 300);
});

document.getElementById('sidebarToggle')?.addEventListener('click', () => {
    document.getElementById('sidebar')?.classList.toggle('open');
    document.getElementById('sidebarOverlay')?.classList.toggle('visible');
});

document.getElementById('sidebarOverlay')?.addEventListener('click', closeSidebar);

switchSection('dashboard');
